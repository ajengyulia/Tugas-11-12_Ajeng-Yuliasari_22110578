
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-border">Contact Form</div>
        <div class="card-body">
            <h2>Thank You!!!!!</h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ajeng Yuliasari\Downloads\pemweb2\pemweb2\resources\views/contact/thanks.blade.php ENDPATH**/ ?>