
<?php $__env->startSection('content'); ?>

    <div class="card">
        <div class="card-border">Contact Form</div>
        <div class="card-body">
            <h2>Welcome!!!!</h2>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('student.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pemweb2\resources\views/login/home.blade.php ENDPATH**/ ?>